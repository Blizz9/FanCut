My Nes GTK source
-----------------
Copyright � Ala Ibrahim Hadid 2009 - 2015. All rights reserved.
E-mail: ahdsoftwares@hotmail.com
Website: http://sourceforge.net/projects/mynes/

For My nes GTK solution, I use Xamarin Studio, It should work on VS and MonoDevelop too.
The only reason I use Xamarin Studio is for GTK windows design.

After opening the solution, you'll need to add reference in My Nes SDL to the
"Core.dll" which it's the core dll of My Nes, you can get it from My Nes website. 
Just download the latest version binary files then add the Core.dll file.

SDLDotNet project is not required, you can use the SDLDotNet dll instead. I just
include it in this solution to make tests on build configurations (X86 and X64).

Links:
------

E-Mail: ahdsoftwares@hotmail.com

Main Website include information, forums, source code and more: http://sourceforge.net/projects/mynes/

Article about My Nes on CodeProject.com: http://www.codeproject.com/KB/game/MyNes_NitendoEmulator.aspx

Facebook page: http://www.facebook.com/pages/My-Nes/427707727244076